# Distrito Domo

Simulador de ciudad retro, en pixel art isométrico, ambientado en el Distrito Domo de Santa Catarina, Nuevo León. Idea y dirección: Mauricio. Programación, pixel art y jazz: Claude.

El juego es un solo archivo HTML sin dependencias: corre en cualquier navegador, como artifact de claude.ai o en itch.io.

## Cómo está organizado

```
src/
  index.html        la página: cabecera, barra, paneles; {{CSS}} y {{JS}} se rellenan al armar
  css/juego.css     todos los estilos
  js/orden.json     el orden en que se pegan los archivos de js/ (importa: ver abajo)
  js/*.js           el juego, por partes
  js/arte/*.js      el dibujo de cada edificio
dist/
  distrito-domo.html   el juego armado (este es el que se publica)
tools/              armar, revisar y empaquetar (Node, sin dependencias salvo eslint)
tests/              pruebas en navegador (Python + Playwright) y bots de balance
docs/               notas del proyecto
legacy/             (ya no existe en main; está en el historial: versiones v53–v64 tal como se publicaron)
```

### Las partes del juego (`src/js`, en orden)

| Archivo | Qué tiene |
|---|---|
| `errores.js` | Registro de los últimos 20 errores en el navegador |
| `datos.js` | Perillas de economía (`ECO`), opciones, `DEFS` (todos los edificios), niveles y nombres |
| `estado.js` | Partida nueva, terrenos, guardado, tipos de vecinos y gustos |
| `obras.js` | Obras grandes: constantes y ayudas |
| `simulacion.js` | `recompute`, `satCalc`, `tick`: plusvalía, clientela, satisfacción, llegadas y salidas, eventos, quejas |
| `encargos.js` | Los 24 encargos, su motor y su panel |
| `mensajes.js`, `dia-noche.js` | Mensajes tipo GameBoy, reloj y luz |
| `dibujo.js` | Primitivas de pixel art: cajas, caras, ventanas, árboles, gente |
| `arte/*.js` | Un archivo por familia de edificios |
| `objetos.js` | `drawObj`: qué dibujo le toca a cada casilla |
| `vehiculos.js`, `transeuntes.js`, `cielo.js` | Coches, camión, tráiler, gente caminando, cielo y sierra |
| `huella.js` | Edificios de varias casillas (2×1, 2×2, 3×3) |
| `fuegos.js`, `juice.js` | Fuegos, polvo, destello, confeti, obra piso por piso, momentos de cámara, zoom suave |
| `render.js` | Imágenes en caché, sombras, suelo, el cuadro completo, la manita |
| `interfaz.js`, `entrada.js`, `pantalla.js` | Barra y paneles; mouse, toque, rueda y pellizco; rendimiento y orientación |
| `musica.js` | Jazz procedural y efectos de sonido |
| `arranque.js` | Cargar la partida y el ciclo principal |

**Importante:** todo el código vive dentro de un mismo cierre `(()=>{ … })()` que abre `datos.js` y cierra `arranque.js`. Los archivos no son módulos: se pegan uno tras otro en el orden de `orden.json`, así que todos ven las variables de todos. Un archivo nuevo se agrega a `orden.json` en el lugar que le toque. El siguiente paso de la base técnica sería pasarlos a módulos de verdad, poco a poco.

## Trabajar en el juego

Hace falta Node 18 o más (y Python 3 con Playwright para las pruebas).

```bash
npm run build      # arma dist/distrito-domo.html
npm run lint       # variables sin definir y otros errores (necesita «npm install» una vez)
npm run itch       # arma dist/distrito-domo-itch.zip para itch.io
npm test           # revisión + pruebas en navegador
npm run bots       # bots de balance (tardan: horas de juego simulado)
```

Para una versión nueva:

1. Cambiar lo que haga falta en `src/`.
2. `npm run build` y abrir `dist/distrito-domo.html` en el navegador.
3. `npm test`.
4. Subir `version` en `package.json` (0.64 → 0.65 = v65), hacer commit con lo que cambió.
5. Publicar `dist/distrito-domo.html` en el artifact y, si toca, `npm run itch` para itch.io.

`dist/distrito-domo.html` sí se guarda en git, para que siempre esté a la mano la última versión jugable.

## Pruebas

Todas abren el juego en Chromium con ganchos de prueba (`build/arnes.html`, se arma con `npm run arnes`). Lo que generan (capturas, resultados) queda en `build/`, que git ignora.

| Prueba | Qué revisa |
|---|---|
| `tests/monkey.py` | Toques, teclas, arrastres y rueda al azar en laptop y celular; falla si hay cualquier error. `TODO=1` abre todos los edificios, `SEG=40` cambia la duración |
| `tests/opciones.py` | Calidad baja, Alto contraste, Menos movimiento y Día de Muertos |
| `tests/obras.py` | Pone las 6 obras grandes en una ciudad de 2,600 vecinos y captura cada etapa de obra |
| `tests/escena.py` | Escena con todas las obras, en los 4 giros |
| `tests/juice.py` | Momento del Domo, confeti, zoom con rueda e inercia |
| `tests/bots/correr.py` | Bots novato, intermedio, experto, muy experto y descuidado (`SEEDS=1,2,3`, `NOSTOP=1`) |

Para usar otro Chromium: `CHROME=/ruta/al/chrome`.

## Pendientes conocidos

Ver `docs/pendientes.md`. Para una versión comercial, antes que nada hay que resolver el uso de marcas e instituciones reales (Banregio, DeAcero, UDEM, Tec y el propio Distrito Domo).

El revisor marca que `slide` y `swings` están definidas dos veces (en `arte/escuela.js` y `arte/areas-verdes.js`). Gana la segunda, así que la escuela y el parque usan el mismo dibujo de columpios y resbaladilla. Viene de antes y no rompe nada, pero conviene renombrar una.
